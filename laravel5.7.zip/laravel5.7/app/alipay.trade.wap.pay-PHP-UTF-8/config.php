<?php
$config = array(
		//应用ID,您的APPID。
		'app_id' =>"2016092500595896",

		//商户私钥
		'merchant_private_key' => "MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQDE1vx1esb4Xi12FgUyBIn5Ga2HJgURYk4wcnBXOmHkSD68swi0AAjbTePamMoDgU9GlBAoAkCIg7Sem49szxdfdsLJpdQ55Q/MzipKUXEi44upJg9mzrWUW9QDLsOH+xnws/pYtkoxy8gxc1ApYRN9iKB9N/HVCD3eT3+iBJa+OAjcGLqJ2ckWsBwAlUtTJq3+gK+oKuCYnk7eax3YN+2yzXbkNZ88bXOBG0dYNUPqndOhuRoOBvpDFnPSGmWbEH0xpCDYz+T5hIJcCOkuYlLqgkdmNAXU5qxGZH4wba/yOawfyiZaKHzL+VfrXvMV2h8wE7p0d/f5jFnKo2sc1TnFAgMBAAECggEAGU3t7IhZFcq9m2WfS1vMBOrpJOudUSvLE21SxdPqi7dB4W4+my059j9gIFTt+19fOpqELTCE7UfJK26iFIHW5l3VEqkvzDWHP3PtedpYafzIknkjF7tRGn5nlfUoC84a+peYglkE1rv0w26oinlBUS0EPLS5cQJ7OZ4MsV5XpqJBsDeHxa3Xapv2W0vPvgI9RHac+bWVfvq0vUhiGklQWvDkMc8S/NqPiAs15nKfnzcLQqwliyuO/QjZ4nUwcFfjfJxF/0WFz5UL7njQ9iOV1rMOw8YO73YNdCiSroPrNmlkLgM/qtHWzKLkv4NyhwuVRbdwFXT9KNUxZVCQMiwIbQKBgQDrxZ/bjuAMHEF3a2oI7ovP5CrdsjQNn0HjU025GbNkUwWpnql0rW2OTpDNr2sQKjxIuZgnepb0BSKjZD0qyZ+k2cAd/ks+gUbgeb7oO1dUlAKeed3+O6/2ISGysR7rf3rjc6Qy9fCk3ZdbP+o3wxUMGI2g0xd1Ro9Unuz6hADTfwKBgQDVukZuVYGmmcN7IPA3+eQHMYXwF/qtR1MhbtJrj4dXzqaOQr5uMxDmTachdbnSdhFPTGtyZjCqTpvRyYFgcyyalZS/IzcqAaZD6llV2TqUCjQD/pKoeax1em5vB9+YGvkLuLcFpreYxm9QjW3NctqT+qqJ6LCuCODQtaKFinNEuwKBgGj8rG15Vr0ty90ggKwPhUSChrAHzXQPaaiPjLmS/zX6XjgkxbKGE5Xd2E8vAM7G7+c2ddGGnjd1HfKCDVbDR4qByDHS7bCconIM5HzHB+FKs0vcWoT+ESHZqQbIJkuZjaBA+2oR6CGR5vckI+jGvtWPDWoC9ZwsWmDFECORqkiDAoGAJFbauNHTDIeiZCISlgHoEo0KD+uT1LiG2u1j26P4yCY7zX5tsIEAQ5g6bYb9xFoM0WXV8wqLBbn95mqTk9mhYNtEAkezjnHfWjbTX7RisF8XvwIe34RonUTm1/wHuW4EoEiU3eId310F+jVB0SfRIE4DhxVITR73UqU/b+M9fBcCgYAp6BpPxp0oSHd1hpn4aoE3lrD5MSknL6TOqln5bsMhbxyj21AwZdULyRheaWftx9Fg4z/Ix4ONBL8kjovkNW+peg98ZwojMqY0FwazcTxo97tIfLdznq00qu44N4kkCKOjjkOSYBKaezU8BCcwAkEM5h8CAETAXa9DOmQ5V/FBUw==",
		
		//异步通知地址
		'notify_url' => "http://localhost/alipay.trade.wap.pay-PHP-UTF-8/notify_url.php",
		
		//同步跳转
		'return_url' => "http://localhost/alipay.trade.wap.pay-PHP-UTF-8/return_url.php",

		//编码格式
		'charset' => "UTF-8",

		//签名方式
		'sign_type'=>"RSA2",

		//支付宝网关
		'gatewayUrl' => "https://openapi.alipaydev.com/gateway.do",

		//支付宝公钥,查看地址：https://openhome.alipay.com/platform/keyManage.htm 对应APPID下的支付宝公钥。
		'alipay_public_key' => "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtm9WXkrvgCPTYYH2WibrpQqkskoiphKtUvy0ZfpsXGmNlawmH3EfzevhRGDXIB/5yYYk1LEzekcIAPbg89H1mn77y7BgDD/IywffBM+pGT2jVv3WsLNb6LzxuJwugevld+CaOiPDVHT9lQ7UkkvsR8iNvqpfo7IOviWnAUP5CrQ1pFeRyBs/1XA6YBw9Jgwt28qGDI9UTeHGSi1nVCHxKjnoqVdiYl3DrqUf+ajNDnCqKJt41jdROoBZ3v8/Bnc+2Lv5G7pjAf928Xxn01quv6W76UgTUyCeCbeOO/UB+rzp2UPb7ZO/tu+kBKAMqHC6QEQBA5pbJKrud2tmOjdZ0QIDAQAB",
);